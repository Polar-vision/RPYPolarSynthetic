# Supplementary material

**A decision rule without an operating characteristic: the pairwise sum in conformance assessment of multi-channel boresight alignment**

Zhengkang Zuo, Polar-vision Laboratory, College of Geoscience and Surveying Engineering, Taiyuan University of Technology, Taiyuan 030024, Shanxi, China. zuozhengkang@tyut.edu.cn

This package reproduces every number, table and figure in the manuscript.

## Layout

```
analysis/data/lro_alignment_allocations.csv   ten allocations transcribed from
                                              NASA 431-SPEC-000113 Rev A, each
                                              with its clause number and the
                                              verbatim sentence quoted
analysis/figures/                             output directory for the figures
src/rpy_polar_synth/                          solver and supporting modules
run_p3_replay.py                              replay of the specification
                                              (Section 5, Figure 2)
run_regime_map.py                             channel-count / ratio /
                                              heterogeneity sweeps (Section 6)
plot_paper_fig1.py                            Figure 1
plot_p3_replay.py                             Figure 2
plot_regime.py                                Figure 3
outputs_p3/                                   derived CSV and JSON behind every
                                              stated value
```

## Reproduce

Run everything from the package root; the scripts resolve paths relative to it.

```
python -m venv .venv
.venv\Scripts\activate            # POSIX: . .venv/bin/activate
pip install -r requirements.txt

set PYTHONPATH=src                # POSIX: export PYTHONPATH=src

python run_p3_replay.py           # rewrites outputs_p3/lro_channels.csv,
                                  # rescue_curve.csv, production_view.csv,
                                  # summary.json
python run_regime_map.py          # rewrites the regime_* files
python plot_paper_fig1.py         # Figure 1
python plot_p3_replay.py          # Figure 2
python plot_regime.py             # Figure 3
```

## Notes

- The solver `p3_replay.py` enumerates candidate common orientations; every reported
  feasibility verdict was cross-checked against an independent spherical-cap solver
  implemented in `replication.py`. The two agree on all 300 random instances tested.
- The specification itself is not redistributed. The transcription keeps the clause
  number and the verbatim sentence for each allocation, so every value can be traced
  to the public document.
