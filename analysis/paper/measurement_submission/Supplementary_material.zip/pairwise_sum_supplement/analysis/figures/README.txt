The figure scripts write their PNG output into this directory.
